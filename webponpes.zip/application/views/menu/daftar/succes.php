<!DOCTYPE html>
<html>
<head>
    <title>Pendaftaran Berhasil</title>
</head>
<body>
    <h2>Pendaftaran Berhasil</h2>
    <p>Terima kasih telah mendaftar. Berikut adalah Nomor Induk Santri:</p>
    <h3><?php echo $kode_unik; ?></h3>
    <br>
    <a href="<?php echo site_url(); ?>"><button>Kembali ke Halaman Utama</button></a>
</body>
</html>
