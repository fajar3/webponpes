<!-- 
    <div class="btn-container">
        <a href="<?= site_url('admin/login') ?>" class="btn-member">admin</a>
        <a href="<?= site_url('admin/register') ?>" class="btn-member">register</a>
    -->